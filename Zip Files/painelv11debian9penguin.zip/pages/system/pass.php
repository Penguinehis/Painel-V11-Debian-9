<?php $pass = 'suasenha';?>
